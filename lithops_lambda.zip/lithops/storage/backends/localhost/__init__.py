from .localhost import LocalhostStorageBackend as StorageBackend

__all__ = ['StorageBackend']
