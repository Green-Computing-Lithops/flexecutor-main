from .globber import match

__all__ = [
    'match'
]

name = 'globber'
